﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.XPath;

namespace PFerramenta0030482423033
{
    internal class Ferramenta
    {
        public int IdFerramenta { get; set; }

        public string Nome { get; set; }
        public string Distribuicao { get; set; }
        public DateTime DtCadastro { get; set; }
        public string SiteOficial { get; set; }
        public int IdCategoria { get; set; }
        public string IdFabricante { get; set; }

        
    
    }
}
